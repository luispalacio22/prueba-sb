package com.codility.utils;

import org.springframework.stereotype.Component;

@Component
public class Util {
    public void performUtilityFunction() {
        System.out.println("utilidad ejecutada.");
    }
}
