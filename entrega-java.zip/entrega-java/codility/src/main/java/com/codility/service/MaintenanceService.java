package com.codility.service;

public class MaintenanceService {

    public MaintenanceService() {

    }
    public void performMaintenance() {
        System.out.println("Mantenimiento realizado.");
    }
}
